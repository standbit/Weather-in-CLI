# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['wttr_package']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['script = wttr_package.main:main']}

setup_kwargs = {
    'name': 'weather checker',
    'version': '0.1.0',
    'description': 'tool, which helps in cheking weather, work with HTTP requests',
    'long_description': None,
    'author': 'Stanislav',
    'author_email': 'yastva3@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
